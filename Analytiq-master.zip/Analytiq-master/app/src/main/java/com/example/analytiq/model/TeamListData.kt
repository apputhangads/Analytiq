package com.example.analytiq.model

data class TeamListData (
    val name:String,
    val desc:String,
    val image:Int
)