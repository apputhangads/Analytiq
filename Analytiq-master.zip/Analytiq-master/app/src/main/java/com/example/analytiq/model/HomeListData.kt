package com.example.analytiq.model

import android.graphics.drawable.Drawable
import android.widget.ImageView

data class HomeListData(
    val color: Int,
    val name: String,
    val image: Int
)